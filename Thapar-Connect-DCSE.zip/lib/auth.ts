import { betterAuth } from 'better-auth'
import { createHmac } from 'node:crypto'
import { prismaAdapter } from 'better-auth/adapters/prisma'
import { emailOTP } from 'better-auth/plugins'
import { db } from './db'
import { sendMail } from './mail'

export const googleEnabled = Boolean(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET)
export const auth = betterAuth({
  database: prismaAdapter(db, { provider: 'postgresql', transaction: true }),
  emailAndPassword: {
    enabled: true, disableSignUp: true, requireEmailVerification: true,
    minPasswordLength: 12, maxPasswordLength: 128, revokeSessionsOnPasswordReset: true,
    sendResetPassword: async ({ user, url }) => sendMail(user.email, 'Reset your Thapar Connect password', 'Open this link to choose a new password: ' + url),
  },
  socialProviders: googleEnabled ? { google: {
    clientId: process.env.GOOGLE_CLIENT_ID!, clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
    hd: 'thapar.edu', disableSignUp: true, disableImplicitSignUp: true,
  } } : {},
  session: { cookieCache: { enabled: false }, expiresIn: 60 * 60 * 24 * 7 },
  rateLimit: { enabled: true, storage: 'database', window: 60, max: 40,
    customRules: { '/sign-in/email': { window: 60, max: 5 }, '/email-otp/send-verification-otp': { window: 60, max: 3 } } },
  databaseHooks: {
    user: { create: { before: async () => false } },
    session: { create: { before: async (session, ctx) => {
      const user = await db.user.findUnique({ where: { id: session.userId } })
      if (!user?.emailVerified || user.suspended || !user.email.endsWith('@thapar.edu')) return false
      if (user.role === 'ADMIN' && ctx?.path !== '/sign-in/email') return false
      return { data: session }
    }, after: async session => {
      await db.auditLog.create({ data: { actorId: session.userId, action: 'SESSION_CREATED' } })
    } } },
  },
  plugins: [emailOTP({
    disableSignUp: true, otpLength: 6, expiresIn: 600, allowedAttempts: 5,
    storeOTP: { hash: async otp => createHmac('sha256',process.env.BETTER_AUTH_SECRET!).update('login:'+otp).digest('hex') },
    async sendVerificationOTP({ email, otp, type }) {
      if (type !== 'sign-in' || !email.endsWith('@thapar.edu')) return
      const user = await db.user.findUnique({ where: { email } })
      if (user && user.role !== 'ADMIN' && !user.suspended) await sendMail(email, 'Sign in to Thapar Connect', 'Your sign-in code is ' + otp + '. It expires in 10 minutes.')
    },
  })],
})
