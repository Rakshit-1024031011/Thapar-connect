import { createHash, createHmac, randomBytes, randomInt, randomUUID } from 'node:crypto'
import { hashPassword } from 'better-auth/crypto'
import type { Prisma } from '@prisma/client'
import { z } from 'zod'
import { db } from './db'
import { sendMail } from './mail'

export const address = z.string().trim().toLowerCase().email().max(254).endsWith('@thapar.edu')
const label = z.string().trim().min(1).max(120)
const password = z.string().min(12).max(128)
const otp = z.string().regex(/^\d{6}$/)
export const studentFields = z.strictObject({
  email: address, name: label, password, studentId: z.string().trim().toUpperCase().regex(/^[A-Z0-9-]{3,32}$/),
  departmentId: label, year: z.number().int().min(1).max(8), code: otp,
})
export const invitationFields = z.strictObject({ email: address, name: label, employeeId: label, departmentId: label, designation: label })
export const activationFields = z.strictObject({ token: z.string().regex(/^[0-9a-f]{64}$/), password })
export const codeField = z.strictObject({code: otp})
export class InputError extends Error {
  constructor(message: string, readonly status = 400) { super(message) }
}
function digest(key: string, code: string) {
  const secret = process.env.BETTER_AUTH_SECRET
  if (!secret || secret.length < 32) throw new Error('Missing application secret')
  return createHmac('sha256',secret).update(key + ':' + code).digest('hex')
}
export async function issueCode(key: string, email: string) {
  const code = randomInt(1000000).toString().padStart(6, '0')
  const hash = digest(key, code)
  const limitKey = 'campus-mail:' + tokenHash(key)
  const now = BigInt(Date.now())
  const cutoff = now - BigInt(3600000)
  const allowed = await db.$executeRaw`INSERT INTO "RateLimit" ("id","key","count","lastRequest")
    VALUES (${randomUUID()}, ${limitKey}, 1, ${now})
    ON CONFLICT ("key") DO UPDATE SET
      "count"=CASE WHEN "RateLimit"."lastRequest" < ${cutoff} THEN 1 ELSE "RateLimit"."count"+1 END,
      "lastRequest"=CASE WHEN "RateLimit"."lastRequest" < ${cutoff} THEN ${now} ELSE "RateLimit"."lastRequest" END
    WHERE "RateLimit"."count" < 8 OR "RateLimit"."lastRequest" < ${cutoff}`
  if (!allowed) throw new InputError('Too many code requests. Try again in an hour.',429)
  const written = await db.$executeRaw`INSERT INTO "StudentChallenge" ("email", "digest", "expiresAt", "sentAt", "attempts")
    VALUES (${key}, ${hash}, (NOW() AT TIME ZONE 'UTC') + interval '10 minutes', (NOW() AT TIME ZONE 'UTC'), 0)
    ON CONFLICT ("email") DO UPDATE SET "digest"=EXCLUDED."digest", "expiresAt"=EXCLUDED."expiresAt", "sentAt"=EXCLUDED."sentAt", "attempts"=0
    WHERE "StudentChallenge"."sentAt" < EXCLUDED."sentAt" - interval '1 minute'`
  if (!written) throw new InputError('Wait a minute before requesting another code.', 429)
  await sendMail(email, 'Your Thapar Connect verification code', 'Enter ' + code + ' within 10 minutes.')
}
async function consumeCode(tx: Prisma.TransactionClient, key: string, code: string) {
  const where = { email:key, expiresAt:{gt:new Date()}, attempts:{lt:5} }
  const consumed = await tx.studentChallenge.deleteMany({where:{...where,digest:digest(key,code)}})
  if (consumed.count) return true
  await tx.studentChallenge.updateMany({where,data:{attempts:{increment:1}}})
  return false
}
export async function registerStudent(input: z.infer<typeof studentFields>) {
  const ok = await db.$transaction(async tx => {
    if (!await consumeCode(tx,'student:'+input.email,input.code)) return false
    if (await tx.teacherInvitation.findUnique({where:{email:input.email}})) throw new InputError('Use your faculty invitation.')
    const user = await tx.user.create({data:{
      name:input.name,email:input.email,emailVerified:true,role:'STUDENT',
      student:{create:{studentId:input.studentId,departmentId:input.departmentId,year:input.year}},
    }})
    await tx.account.create({data:{accountId:user.id,userId:user.id,providerId:'credential',password:await hashPassword(input.password)}})
    await tx.auditLog.create({data:{actorId:user.id,action:'STUDENT_REGISTERED'}})
    return true
  })
  if (!ok) throw new InputError('Invalid or expired code.')
}
const tokenHash = (token:string) => createHash('sha256').update(token).digest('hex')
export async function inviteTeacher(actorId:string, input:z.infer<typeof invitationFields>) {
  const token = randomBytes(32).toString('hex')
  const fields = {...input, issuedBy:actorId, tokenHash:tokenHash(token), expiresAt:new Date(Date.now()+86400000)}
  await db.$transaction(async tx => {
    if (await tx.user.findUnique({where:{email:input.email}})) throw new InputError('This address already has an account.',409)
    const invite = await tx.teacherInvitation.upsert({where:{email:input.email}, create:fields, update:fields})
    await tx.auditLog.create({data:{actorId, action:'TEACHER_INVITED',targetId:invite.id}})
  })
  await sendMail(input.email,'Your Thapar Connect faculty invitation','Set your password within 24 hours: '+process.env.BETTER_AUTH_URL+'/login/activate#'+token)
}
export async function activateTeacher(input:z.infer<typeof activationFields>) {
  const hash = tokenHash(input.token)
  await db.$transaction(async tx => {
    const used = await tx.teacherInvitation.updateMany({where:{tokenHash:hash,consumedAt:null,expiresAt:{gt:new Date()}},data:{consumedAt:new Date()}})
    if (!used.count) throw new InputError('Invalid or expired invitation.')
    const invite = await tx.teacherInvitation.findUniqueOrThrow({where:{tokenHash:hash}})
    const user = await tx.user.create({data:{email:invite.email,name:invite.name,emailVerified:true,role:'TEACHER',
      teacher:{create:{employeeId:invite.employeeId,departmentId:invite.departmentId,designation:invite.designation}}}})
    await tx.account.create({data:{accountId:user.id,userId:user.id,providerId:'credential',password:await hashPassword(input.password)}})
    await tx.auditLog.create({data:{actorId:user.id,action:'TEACHER_ACTIVATED'}})
  })
}
export async function verifyAdmin(sessionId:string, actorId:string, code:string) {
  const ok = await db.$transaction(async tx => {
    if (!await consumeCode(tx,'admin:'+sessionId,code)) return false
    await tx.verification.create({data:{id:randomUUID(),identifier:'admin-grant:'+sessionId,value:'verified',expiresAt:new Date(Date.now()+3600000)}})
    await tx.auditLog.create({data:{actorId,action:'ADMIN_SECOND_FACTOR_VERIFIED'}})
    return true
  })
  if (!ok) throw new InputError('Invalid or expired code.')
}

