import { test, after } from 'node:test'
import assert from 'node:assert/strict'
import { randomUUID, randomBytes, createHmac, createHash } from 'node:crypto'
import { PrismaClient } from '@prisma/client'
import { hashPassword } from 'better-auth/crypto'

const db = new PrismaClient()
const origin = process.env.BETTER_AUTH_URL
if (!origin || !['localhost','127.0.0.1'].includes(new URL(origin).hostname) || process.env.CAMPUS_TEST_DATABASE !== 'disposable') {
  throw Error('Run against a local app and disposable database. Set CAMPUS_TEST_DATABASE=disposable.')
}
const tag = randomUUID()
const email = tag+'@thapar.edu'
const password = randomBytes(24).toString('hex')
const code = '091423'
const hash = (value) => createHash('sha256').update(value).digest('hex')
function post(path, body, cookie='') {
  return fetch(origin+path,{method:'POST',headers:{Origin:origin,'Content-Type':'application/json',Cookie:cookie},body:JSON.stringify(body),redirect:'manual'})
}
function cookies(response) {
  return response.headers.getSetCookie().map(line=>line.split(';')[0]).join('; ')
}
async function challenge(key, expired=false) {
  const fields = {digest:createHmac('sha256',process.env.BETTER_AUTH_SECRET).update(key+':'+code).digest('hex'),attempts:0,expiresAt:new Date(Date.now()+(expired?-60000:60000))}
  await db.studentChallenge.upsert({where:{email:key},create:{email:key,...fields},update:fields})
}
after(()=>db.$disconnect())

test('institutional enrollment, faculty invitations and protected account sessions',async t=>{
  const department = await db.department.create({data:{name:'Test '+tag}})
  const student = {email,name:'Test student',studentId:tag.slice(0,8),year:2,departmentId:department.id,password,code}
  const register = body=>post('/api/campus/register',body)
  let studentCookie, adminCookie, admin
  await t.test('server rejects role input, external email and public privilege creation',async()=>{
    assert.equal((await register({...student,role:'TEACHER'})).status,400)
    assert.equal((await register({...student,email:'test@example.com'})).status,400)
    assert.equal((await post('/api/auth/sign-up/email',{email,password,name:'Test'})).status,404)
    assert.equal((await post('/api/campus/invite',{})).status,403)
  })
  await t.test('expired codes and attempt exhaustion',async()=>{
    await challenge('student:'+email,true)
    assert.equal((await register(student)).status,400)
    await challenge('student:'+email)
    for (let i=0;i<5;i++) assert.equal((await register({...student,code:'000000'})).status,400)
    assert.equal((await register(student)).status,400)
    assert.equal((await post('/api/campus/student-code',{email})).status,429)
  })
  await t.test('one verified account and unique student ID',async()=>{
    await challenge('student:'+email)
    assert.equal((await register(student)).status,200)
    assert.equal((await register(student)).status,400)
    const other='b'+email
    await challenge('student:'+other)
    assert.equal((await register({...student,email:other})).status,409)
    assert.equal(await db.user.count({where:{email:other}}),0)
  })
  await t.test('student sign-in and route ownership',async()=>{
    const login=await post('/api/auth/sign-in/email',{email,password})
    assert.equal(login.status,200)
    studentCookie=cookies(login)
    assert.ok(studentCookie)
    const page=path=>fetch(origin+path,{headers:{Cookie:studentCookie},redirect:'manual'})
    assert.equal((await page('/account/student')).status,200)
    const anonymous = await fetch(origin+'/directory',{redirect:'manual'})
    assert.equal(anonymous.status,307)
    const office = await (await page('/directory?floor=6&q=Aashima')).text()
    assert.match(office,/aashima.sharma@thapar.edu/)
    assert.match(office,/616/)
    assert.doesNotMatch(await (await page('/directory?floor=0&q=Aashima')).text(),/mailto:aashima.sharma/)
    const timetable = await (await page('/directory?view=contacts&q=Timetable')).text()
    assert.match(timetable,/mailto:ttcoordinator_csed@thapar.edu/)
    assert.match(timetable,/mailto:nitin.saxena@thapar.edu/)
    const namesakes = await (await page('/directory?q=Dr.%20Harpreet%20Singh')).text()
    assert.match(namesakes,/mailto:harpreet.singh1@thapar.edu/)
    assert.match(namesakes,/mailto:harpreet.s@thapar.edu/)
    assert.equal(await db.dcseFaculty.count(),153)
    assert.equal(await db.dcseResponsibility.count(),73)
    assert.equal((await page('/account/admin')).status,307)
    assert.equal((await post('/api/campus/suspend',{email},studentCookie)).status,403)
  })
  await t.test('passwordless sign-in consumes its OTP',async()=>{
    const digest = createHmac('sha256',process.env.BETTER_AUTH_SECRET).update('login:'+code).digest('hex')
    await db.verification.create({data:{id:randomUUID(),identifier:'sign-in-otp-'+email,value:digest+':0',expiresAt:new Date(Date.now()+60000)}})
    const login=()=>post('/api/auth/sign-in/email-otp',{email,otp:code})
    const result=await login()
    assert.equal(result.status,200)
    assert.ok(cookies(result))
    assert.ok((await login()).status>=400)
  })
  await t.test('password reset consumes its token and revokes previous sessions',async()=>{
    const token = randomBytes(24).toString('hex')
    const user = await db.user.findUniqueOrThrow({where:{email}})
    await db.verification.create({data:{id:randomUUID(),identifier:'reset-password:'+token,value:user.id,expiresAt:new Date(Date.now()+60000)}})
    const callback = await fetch(origin+'/api/auth/reset-password/'+token+'?callbackURL='+encodeURIComponent(origin+'/login/reset'),{redirect:'manual'})
    assert.equal(new URL(callback.headers.get('location')).searchParams.get('token'),token)
    const reset=()=>post('/api/auth/reset-password',{token,newPassword:password+'new'})
    assert.equal((await reset()).status,200)
    assert.ok((await reset()).status>=400)
    assert.equal(await db.session.count({where:{userId:user.id}}),0)
    const login=await post('/api/auth/sign-in/email',{email,password:password+'new'})
    assert.equal(login.status,200)
    studentCookie=cookies(login)
  })
  await t.test('admin requires a second factor tied to the session',async()=>{
    const adminEmail='a'+email
    admin=await db.user.create({data:{name:'Test admin',email:adminEmail,role:'ADMIN',emailVerified:true}})
    await db.account.create({data:{userId:admin.id,accountId:admin.id,providerId:'credential',password:await hashPassword(password)}})
    const login=await post('/api/auth/sign-in/email',{email:adminEmail,password})
    assert.equal(login.status,200)
    adminCookie=cookies(login)
    assert.equal((await post('/api/campus/suspend',{email},adminCookie)).status,403)
    const session=await db.session.findFirstOrThrow({where:{userId:admin.id}})
    await challenge('admin:'+session.id)
    assert.equal((await post('/api/campus/admin-verify',{code},adminCookie)).status,200)
  })
  await t.test('invitation activation is single use',async()=>{
    const token=randomBytes(32).toString('hex')
    await db.teacherInvitation.create({data:{tokenHash:hash(token),name:'Test faculty',email:'t'+email,employeeId:tag,departmentId:department.id,designation:'Faculty',issuedBy:admin.id,expiresAt:new Date(Date.now()+60000)}})
    const activate=()=>post('/api/campus/activate',{token,password})
    assert.deepEqual((await Promise.all([activate(),activate()])).map(r=>r.status).sort(),[200,400])
    assert.equal((await db.user.findUniqueOrThrow({where:{email:'t'+email}})).role,'TEACHER')
  })
  await t.test('suspension revokes existing sessions and prevents new access',async()=>{
    assert.equal((await post('/api/campus/suspend',{email},adminCookie)).status,200)
    const page=await fetch(origin+'/account/student',{headers:{Cookie:studentCookie},redirect:'manual'})
    assert.equal(page.status,307)
    const login=await post('/api/auth/sign-in/email',{email,password:password+'new'})
    assert.equal(cookies(login).includes('session_token='),false)
    assert.equal((await post('/api/auth/sign-out',{},adminCookie)).status,200)
    assert.equal((await post('/api/campus/suspend',{email},adminCookie)).status,403)
  })
})
