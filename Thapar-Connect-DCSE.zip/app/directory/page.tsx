import Link from 'next/link'
import { redirect } from 'next/navigation'
import { principal } from '@/lib/access'
import { db } from '@/lib/db'
import styles from './directory.module.css'

export const metadata = { title: 'DCSE directory · Thapar Connect' }
const source = 'https://docs.google.com/document/d/1k4he9hNU8X-Ns-7YQuo72mMTlj_Ije3MEH3UP5p0II4/mobilebasic'
type Query = Record<string,string | string[] | undefined>

export default async function Directory({searchParams}:{searchParams:Promise<Query>}) {
  const actor = await principal()
  if (!actor) redirect('/login')
  if (!actor.authorized) redirect('/login/challenge')
  const query = await searchParams
  const term = typeof query.q === 'string' ? query.q.trim().slice(0,120) : ''
  const floor = typeof query.floor === 'string' && /^\d$/.test(query.floor) ? Number(query.floor) : undefined
  const contacts = query.view === 'contacts'
  const contains = { contains:term, mode:'insensitive' as const }
  const [faculty, assignments, floors] = await Promise.all([
    contacts ? [] : db.dcseFaculty.findMany({where:{floor,OR:[{name:contains},{office:contains},{email:contains},{designation:contains}]},orderBy:[{name:'asc'},{email:'asc'}]}),
    contacts ? db.dcseResponsibility.findMany({where:{OR:[{topic:contains},{coordinator:contains},{emails:{has:term.toLowerCase()}}]},orderBy:{id:'asc'}}) : [],
    contacts ? [] : db.dcseFaculty.findMany({distinct:['floor'],select:{floor:true},orderBy:{floor:'asc'}}),
  ])
  const count = contacts ? assignments.length : faculty.length
  return <main className={styles.page}>
    <Link href="/account">← My account</Link>
    <header><p>Computer Science &amp; Engineering</p><h1>Department directory</h1></header>
    <nav aria-label="Directory sections">
      <Link href="/directory" aria-current={!contacts?'page':undefined}>Faculty offices</Link>
      <Link href="/directory?view=contacts" aria-current={contacts?'page':undefined}>Who to contact</Link>
    </nav>
    <form action="/directory" className={styles.filters}>
      {contacts && <input type="hidden" name="view" value="contacts"/>}
      <label>{contacts?'Responsibility or coordinator':'Faculty name, email, designation or room'}
        <input key={term} type="search" name="q" defaultValue={term} maxLength={120} placeholder={contacts?'e.g. Timetable':'e.g. Room number 616'}/>
      </label>
      {!contacts && <label>Floor<select key={String(floor)} name="floor" defaultValue={floor??''}><option value="">All floors</option>{floors.map(f=><option key={f.floor} value={f.floor}>{f.floor===0?'Ground floor':'Floor '+f.floor}</option>)}</select></label>}
      <button type="submit">Search</button>
    </form>
    <p>{count} {contacts?(count===1?'assignment':'assignments'):(count===1?'faculty member':'faculty members')}{term && <> matching “{term}”</>}</p>
    {count===0 && <Link href={contacts?'/directory?view=contacts':'/directory'}>Clear search and filters</Link>}
    <ul className={styles.results}>
      {faculty.map(f=><li key={f.email}><h2>{f.name}</h2><p>{f.designation}</p><strong>Office {f.office} · {f.floor===0?'Ground floor':'Floor '+f.floor}</strong><a href={'mailto:'+f.email}>{f.email}</a></li>)}
      {assignments.map(a=><li key={a.id}><h2>{a.topic}</h2><p>{a.coordinator}</p>{a.emails.map(e=><a key={e} href={'mailto:'+e}>{e}</a>)}</li>)}
    </ul>
    <footer>Directory snapshot from 19 November 2026. <a href={source}>View the DCSE profile</a></footer>
  </main>
}
