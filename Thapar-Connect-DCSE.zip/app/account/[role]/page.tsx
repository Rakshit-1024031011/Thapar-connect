import { redirect } from 'next/navigation'
import Link from 'next/link'
import { principal } from '@/lib/access'
import { SessionControls } from '@/components/session-controls'

export default async function Account({params}:{params:Promise<{role:string}>}) {
  const {role} = await params
  const actor = await principal()
  if (!actor) redirect('/login')
  if (actor.user.role.toLowerCase() !== role) redirect('/account')
  if (!actor.authorized) redirect('/login/challenge')
  return <main className="login-page"><section className="login-form-panel"><Link href="/" className="brand">thaparconnect.</Link>
    <div className="login-copy"><span className="login-kicker">{role.toUpperCase()} ACCOUNT</span>
    <h1>Welcome, {actor.user.name}</h1><p>{actor.user.email} · Email verified</p></div>
    {role==='admin' && <p><Link href="/login/invite">Invite faculty</Link>{' · '}<Link href="/login/suspend">Suspend an account</Link></p>}
    <p><Link className="button button-outline" href="/directory">DCSE faculty and coordinators</Link></p>
    <SessionControls/></section></main>
}

