# Thapar Connect

## Run the authentication milestone

Use Node 24 and pnpm 12.3.4. Set up an empty PostgreSQL database and a database user with schema migration permissions. Run the following from the extracted project root.

```sh
pnpm install --frozen-lockfile
cp .env.example .env
```

On PowerShell use `Copy-Item .env.example .env`. Fill in the environment file before continuing.

| Setting | Value |
| --- | --- |
| DATABASE_URL | PostgreSQL connection URL. Use TLS for a hosted database. |
| BETTER_AUTH_URL | Exact public origin, without a trailing slash. Use http://localhost:3000 locally. |
| BETTER_AUTH_SECRET | At least 32 random bytes. Generate using `node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"`. |
| RESEND_API_KEY, EMAIL_FROM | Server-side Resend sending key and a sender on your verified domain. Verify DNS in Resend before testing delivery. |
| GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET | Google Cloud web application credentials. Add the exact redirect URI `<BETTER_AUTH_URL>/api/auth/callback/google`. Configure the consent screen for the institution. Google sign-in is displayed when both values are set. |
| DEPARTMENT_NAME | An approved department. Run the seed once per department before registration. |
| ADMIN_EMAIL, ADMIN_NAME, ADMIN_PASSWORD | Optional initial administrator. Confirm ownership out of band. Supply an institutional address and a unique password of 16–128 characters through a secure environment. Remove these values after provisioning. |

```sh
pnpm exec prisma migrate deploy
pnpm exec prisma generate
pnpm db:seed
pnpm dev
```

Open the configured origin. Register with a campus mailbox, enter the emailed code, then use the protected account page. Faculty must activate an invitation from a verified administrator. The teacher login page links to Admin access. The admin must sign in with a password and verify an emailed code to manage accounts. An admin grant lasts one hour and is bound to that session.

## Source audit

The supplied archive contained a Next.js App Router landing page, loading and login pages, custom responsive CSS, a theme provider and an animated canvas. The faculty and meeting examples were embedded directly in the homepage. The login, registration and recovery controls only changed component state. The homepage offered both student and professor registration. No backend, student directory, account records, role enforcement, Google provider, OTP delivery or dashboard routes existed. The original Next config suppressed TypeScript build failures.

## Data model and access

The migration creates User, Account, Session, Verification and RateLimit for authentication, Department and one-to-one StudentProfile and TeacherProfile for campus records, StudentChallenge for short-lived keyed codes, TeacherInvitation for faculty activation and AuditLog for security-sensitive changes. Database uniqueness covers account email, student and employee IDs, provider identities, session tokens and invitation digests. Registration and activation create the user, profile, credential and audit record in one transaction.

The enrollment service assigns roles. Existing verified campus users may sign in through Google. Public auth endpoints exclude account creation, role editing and user linking APIs. The server rechecks current account status on each protected page and operation. The local seed refuses to promote an existing student or faculty member. Student email verification leaves directoryVerifiedAt empty until an authorized directory check exists.

## Milestone checklist

- [x] Audit the supplied frontend and document the existing behavior.
- [x] Add PostgreSQL authentication schema, migration, department/admin provisioning and server role checks.
- [x] Implement student enrollment, verification, separate login portals, password recovery, faculty invitations, admin step-up, account suspension and session revocation.
- [ ] Validate delivery and recovery against a verified Resend sender and test real institutional Google callbacks.
- [ ] Validate account flows on the deployment domain and complete accessibility and mobile browser checks.
- [ ] Phase 3: editable academic profiles, dedicated dashboards and role-specific navigation.
- [ ] Phase 4: faculty discovery, recurring availability and exceptions, transactional meeting reservations, cancellation/rescheduling history and calendar integration.
- [ ] Phase 5: notifications, reminders, conversations, private document storage, feedback and announcements.
- [ ] Phase 6: analytics, collaboration, recommendations, group meetings and waitlists.
- [ ] Phase 7: complete workflow and security tests, monitoring, backup restoration and production deployment.

For Phase 4, reference student and teacher profiles from Meeting and log state transitions in MeetingHistory. Use a PostgreSQL time-range exclusion constraint for active reservations for each participant. Store availability rules with a named timezone and persist each booked interval as timestamps with time zone. Later collaboration tables should reference authorized meeting participants and explicit recipients. Private storage credentials and Google Calendar scopes will be added with those integrations.

## Verification and deployment

Use a separate disposable database and a local running instance for integration tests. Configure the same DATABASE_URL, BETTER_AUTH_URL and BETTER_AUTH_SECRET for the test command and the app. The suite creates test records and leaves them in the disposable database. Set CAMPUS_TEST_DATABASE=disposable in the test environment and run `node --env-file-if-exists=.env --test tests/auth.test.mjs`. It creates verification fixtures in the database so account and session behavior can be exercised independently of email transport. Use real test inboxes to verify delivery before launch.

Run `pnpm typecheck` and `pnpm build`. On Vercel, import the source with the Next.js preset and Node 24, configure server-side variables for each environment and give previews a separate database and callback origin. Apply reviewed migrations once from a release job before serving the new version. Use a pooled runtime connection for serverless traffic and a direct database connection for the migration job. Take a backup before schema changes, enable point-in-time recovery with the database provider, and test restoration into a separate database. Use `prisma migrate dev` only on a development database to author future migrations.

## Local verification results, 19 November 2026

The migration applied to a disposable PostgreSQL 18 database. The production webpack build and TypeScript check passed on Next.js 16.4.6. The final local HTTP integration run passed all nine scenarios (ten passing test results including the parent suite). It covered role injection and public registration restrictions, OTP expiry and retry limits, duplicate student IDs, session and route ownership, passwordless login, one-time password reset and session revocation, admin step-up, concurrent faculty activation, and suspension. OTPs, invitations and recovery tokens were seeded into the disposable database for these checks. Resend, Google OAuth and Vercel deployment require testing with actual provider configuration.

The original Next.js 16.4.3 was upgraded to 16.4.6 after the npm registry reported two cache-disclosure advisories. The final production-dependency audit still reported 3 high, 23 moderate and 4 low findings. The high findings concern transitive versions of deepmerge-ts, zod and body-parser. The app's direct Zod version resolves to 4.6.7. Assess affected dependency paths and update or replace them before a production release. Recheck the lockfile with pnpm audit --prod. Local functional test results do not resolve dependency advisories.

## DCSE faculty offices and coordinator contacts

Signed-in users can open **DCSE faculty and coordinators** from their account page. Search by name, institutional email, designation or room, or select a floor. The **Who to contact** tab searches coordinator assignments by responsibility, coordinator name or exact contact email. Each contact link opens the user's email application.

The directory migration imports 153 office listings and 73 coordinator assignments from the supplied [DCSE profile](https://docs.google.com/document/d/1k4he9hNU8X-Ns-7YQuo72mMTlj_Ije3MEH3UP5p0II4/mobilebasic), retrieved on 19 November 2026. Role mailboxes and multiple contacts for one responsibility are preserved. Directory entries are independent of login roles and teacher invitations. The document provides a snapshot of office locations and assignments. Changes to the source require a new reviewed migration to update the app. Office hours and meeting availability require faculty input.

For an existing installation, back up the database, run `pnpm exec prisma migrate deploy`, regenerate Prisma Client, rebuild and restart. The migration loads directory data without creating accounts or sending invitations.
The updated production build and integration suite passed locally. Directory checks covered the anonymous redirect, room and floor lookup, same-name faculty, timetable coordinator mailboxes, and both imported row counts.
